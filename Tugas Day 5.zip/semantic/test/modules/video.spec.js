describe("UI Video", function() {

  moduleTests({
    module  : 'video',
    element : '.ui.video'
  });

});